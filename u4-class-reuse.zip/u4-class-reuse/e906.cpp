/******
 * Ky Fike on Apr 8, 2022
 * Exercise 9.06:
 * Rational - Class
 * *****/
/******
 * Ky Fike on Mar 29, 2022
 * Exercise 9.03:
 * Scope Resolution Operator
 * *****/

/*  e03:
The purpose of the scope resolution operator is to access a member function or variable within a certain scope and reduce conflicts in coding logic,
such as having the same object name in two different scopes.
*/
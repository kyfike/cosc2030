/*  Ky Fike
*   May 4, 2022
*/
#include "Card.h"
#include "Deck.h"
#include <iostream>

int main(){
    Deck d;
    //d.shuffle(); // You can uncomment this line to see my shuffle function- which isn't working perfectly.
    d.deal();
    //d.rateScore(); // Functions rateScore and compareHands are incomplete.
    //d.compareHands();
    return 0;
}